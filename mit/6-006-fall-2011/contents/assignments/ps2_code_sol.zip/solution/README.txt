Coding Solution for MIT 6.006 Fall 2011 PS2

The solution distribution contains the following files:
  *circuit.py - contains our implementation of a heap-based priority queue.
  *tests/* - contains the full test suite we use to grade your solutions.